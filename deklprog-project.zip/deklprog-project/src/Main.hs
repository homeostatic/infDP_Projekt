module Main (main) where

import Vars
import Base.Type
-- Main function
main :: IO ()
main = undefined